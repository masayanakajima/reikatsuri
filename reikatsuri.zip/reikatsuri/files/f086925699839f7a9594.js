function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.handle(this, this._handler);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.destroyed()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = option && option.modified ? option.modified : undefined;
          this._destroyedHandler = option && option.destroyed ? option.destroyed : undefined;
          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * Tweenが破棄されたかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.destroyed = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.destroyed() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var AnglerStateBase =
      /** @class */
      function () {
        function AnglerStateBase() {}

        return AnglerStateBase;
      }();

      exports.AnglerStateBase = AnglerStateBase;
    }, {}],
    7: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var AnglerStateBase_1 = require("./AnglerStateBase");

      var entityUtil_1 = require("../Util/entityUtil");

      var WaitState_1 = require("./WaitState");

      var FeverManager_1 = require("../GameManager/FeverManager");

      var commonDefine_1 = require("../Common/commonDefine");

      var DropState =
      /** @class */
      function (_super) {
        __extends(DropState, _super);

        function DropState() {
          return _super !== null && _super.apply(this, arguments) || this;
        }

        DropState.prototype.doAction = function (angler) {
          var distance = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(commonDefine_1.commonDefine.FISH_PULL_SPEED) * 3;
          angler.line.height += distance;
          angler.moveNeedles(distance);

          if (angler.line.height >= 300) {
            if (angler.newNeedleFlag) {
              angler.addNewNeedle();
              angler.newNeedleFlag = false;
            }

            entityUtil_1.entityUtil.changeSpriteSurface(angler.body, angler.scene.assets["tsuribito"]);
            angler.setState(new WaitState_1.WaitState());
          }
        };

        DropState.prototype.onClick = function (angler) {};

        return DropState;
      }(AnglerStateBase_1.AnglerStateBase);

      exports.DropState = DropState;
    }, {
      "../Common/commonDefine": 11,
      "../GameManager/FeverManager": 16,
      "../Util/entityUtil": 40,
      "./AnglerStateBase": 6,
      "./WaitState": 10
    }],
    8: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var AnglerStateBase_1 = require("./AnglerStateBase");

      var AnglerManager_1 = require("../GameManager/AnglerManager");

      var entityUtil_1 = require("../Util/entityUtil");

      var DropState_1 = require("./DropState");

      var ParalysedState =
      /** @class */
      function (_super) {
        __extends(ParalysedState, _super);

        function ParalysedState() {
          var _this = _super.call(this) || this;

          _this.paralysedFrame = 0;
          entityUtil_1.entityUtil.changeSpriteSurface(AnglerManager_1.AnglerManager.getInstance().body, AnglerManager_1.AnglerManager.getInstance().scene.assets["tsuribito3"]);
          AnglerManager_1.AnglerManager.getInstance().thunder.show();
          AnglerManager_1.AnglerManager.getInstance().paralysisSound.play();
          return _this;
        }

        ParalysedState.prototype.onClick = function (angler) {};

        ParalysedState.prototype.doAction = function (angler) {
          this.paralysedFrame++;
          if (this.paralysedFrame >= 60) this.paralysisRelease(angler);
        };

        ParalysedState.prototype.paralysisRelease = function (angler) {
          entityUtil_1.entityUtil.changeSpriteSurface(angler.body, angler.scene.assets["tsuribito"]);
          angler.setState(new DropState_1.DropState());
          angler.thunder.hide();
          angler.newNeedleFlag = false;
        };

        return ParalysedState;
      }(AnglerStateBase_1.AnglerStateBase);

      exports.ParalysedState = ParalysedState;
    }, {
      "../GameManager/AnglerManager": 14,
      "../Util/entityUtil": 40,
      "./AnglerStateBase": 6,
      "./DropState": 7
    }],
    9: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var AnglerStateBase_1 = require("./AnglerStateBase");

      var FeverManager_1 = require("../GameManager/FeverManager");

      var commonDefine_1 = require("../Common/commonDefine");

      var entityUtil_1 = require("../Util/entityUtil");

      var ParalysedState_1 = require("./ParalysedState");

      var DropState_1 = require("./DropState");

      var ScoreManager_1 = require("../GameManager/ScoreManager");

      var PullState =
      /** @class */
      function (_super) {
        __extends(PullState, _super);

        function PullState() {
          return _super !== null && _super.apply(this, arguments) || this;
        }

        PullState.prototype.doAction = function (angler) {
          var distance = -FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(commonDefine_1.commonDefine.FISH_PULL_SPEED);
          angler.line.height += distance;
          angler.moveNeedles(distance);
          this.searchReika(angler);
          if (!angler.newNeedleFlag) angler.newNeedleFlag = this.checkNeedleFull(angler);
          if (this.checkNeedleHeight(angler)) this.checkAndRelease(angler);
        };

        PullState.prototype.onClick = function (angler) {};

        PullState.prototype.checkAndRelease = function (angler) {
          var paralysisFlag = false;
          angler.needles.forEach(function (needle) {
            paralysisFlag = paralysisFlag || needle.getCaughtReikaName() == "unti";
          });

          if (paralysisFlag) {
            this.releaseReika(angler);
            angler.setState(new ParalysedState_1.ParalysedState());
          } else {
            angler.needles.forEach(function (needle) {
              needle.addScoreAndFever();
            });
            entityUtil_1.entityUtil.changeSpriteSurface(angler.body, angler.scene.assets["tsuribito2"]);
            this.releaseReika(angler);
            ScoreManager_1.ScoreManager.getInstance().instantScoreViewer.start();
            angler.setState(new DropState_1.DropState());
          }
        };

        PullState.prototype.searchReika = function (angler) {
          angler.needles.forEach(function (needle) {
            needle.searchReika();
          });
        };
        /*
        * needleが一つでもy座標40以下になったらtrue
        */


        PullState.prototype.checkNeedleHeight = function (angler) {
          var flag = false;
          angler.needles.forEach(function (needle) {
            flag = flag || needle.y <= 40;
          });
          return flag;
        };
        /*
        *needleで空のものが一つもないならtrue
        */


        PullState.prototype.checkNeedleFull = function (angler) {
          var flag = true;
          angler.needles.forEach(function (needle) {
            flag = flag && !needle.IsEmpty;
          });
          return flag;
        };

        PullState.prototype.releaseReika = function (angler) {
          angler.needles.forEach(function (needle) {
            needle.reset();
          });
        };

        return PullState;
      }(AnglerStateBase_1.AnglerStateBase);

      exports.PullState = PullState;
    }, {
      "../Common/commonDefine": 11,
      "../GameManager/FeverManager": 16,
      "../GameManager/ScoreManager": 18,
      "../Util/entityUtil": 40,
      "./AnglerStateBase": 6,
      "./DropState": 7,
      "./ParalysedState": 8
    }],
    10: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var AnglerStateBase_1 = require("./AnglerStateBase");

      var PullState_1 = require("./PullState");

      var WaitState =
      /** @class */
      function (_super) {
        __extends(WaitState, _super);

        function WaitState() {
          return _super !== null && _super.apply(this, arguments) || this;
        }

        WaitState.prototype.doAction = function (angler) {};

        WaitState.prototype.onClick = function (angler) {
          angler.setState(new PullState_1.PullState());
        };

        return WaitState;
      }(AnglerStateBase_1.AnglerStateBase);

      exports.WaitState = WaitState;
    }, {
      "./AnglerStateBase": 6,
      "./PullState": 9
    }],
    11: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      var commonDefine;

      (function (commonDefine) {
        commonDefine.SPAWN_LEFT_ARRAY = [160, 180, 200, 220, 240, 260, 280];
        commonDefine.SPAWN_RIGHT_ARRAY = [180, 200, 220, 240, 260, 280, 300];
        commonDefine.FISH_PULL_SPEED = 5;
        commonDefine.GAME_OVER_TIME = 65000;
        commonDefine.FEVER_MAGNIFICATION = 2;
        commonDefine.MAX_REIKA_POOL = 15;
        commonDefine.READY_TIME = 3;
        commonDefine.ALERT_TIME = 10;
        commonDefine.TIME_X = 590;
        commonDefine.TIME_Y = 20;
        commonDefine.SPAWN_INTERVAL = 1.2;
        commonDefine.NormalReika = {
          speed: 6,
          point: 500,
          swim_src: "normal",
          caught_src: "normal"
        };
        commonDefine.GataReika = {
          speed: 6,
          point: 3000,
          swim_src: "gatareika",
          caught_src: "gatareika"
        };
        commonDefine.NemuReika = {
          speed: 3,
          point: 5000,
          swim_src: "nemureika",
          caught_src: "bikkurireika"
        };
        commonDefine.GyakuReika = {
          speed: 6,
          point: 700,
          swim_src: "gyakureika",
          caught_src: "gyakureika"
        };
        commonDefine.HuwaReika = {
          speed: 7,
          point: 1000,
          swim_src: "huwareika",
          caught_src: "huwareika"
        };
        commonDefine.OdoReika = {
          speed: 7,
          point: 4000,
          swim_src: "odoreika",
          caught_src: "odoreika"
        };
        commonDefine.ReikaTyon = {
          speed: 7,
          point: 1500,
          swim_src: "reikatyon",
          caught_src: "reikatyon"
        };
        commonDefine.YuReika = {
          speed: 8,
          point: 3000,
          swim_src: "yureika",
          caught_src: "yureika"
        };
        commonDefine.TakoReika = {
          speed: 4,
          point: 5500,
          swim_src: "takoreika",
          caught_src: "takoreika"
        };
        commonDefine.YuiZarashi = {
          speed: 4,
          point: 14000,
          swim_src: "yuizarashi2",
          caught_src: "yuizarashi2"
        };
        commonDefine.UntiReika = {
          speed: 3,
          point: 8000,
          swim_src: "untireika",
          caught_src: "untireika"
        };
        commonDefine.Unti = {
          speed: 5,
          point: 0,
          swim_src: "unti",
          caught_src: "unticaught"
        };
      })(commonDefine = exports.commonDefine || (exports.commonDefine = {}));
    }, {}],
    12: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      var DistributionState;

      (function (DistributionState) {
        DistributionState[DistributionState["EARLY"] = 0] = "EARLY";
        DistributionState[DistributionState["MID"] = 1] = "MID";
        DistributionState[DistributionState["LATE"] = 2] = "LATE";
        DistributionState[DistributionState["FEVER"] = 3] = "FEVER";
      })(DistributionState = exports.DistributionState || (exports.DistributionState = {}));
    }, {}],
    13: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SceneBase_1 = require("./SceneBase");

      var DescriptionScene =
      /** @class */
      function (_super) {
        __extends(DescriptionScene, _super);

        function DescriptionScene(property) {
          return _super.call(this, property) || this;
        }

        DescriptionScene.prototype.loadedHandler = function () {
          var _this = this;

          return function () {
            _this.title = new g.Sprite({
              scene: _this,
              src: _this.assets["title"]
            });

            _this.append(_this.title);

            _this.frameCnt = 0;
          };
        };

        DescriptionScene.prototype.updateHandler = function () {
          var _this = this;

          return function () {
            _this.frameCnt++;
            if (_this.frameCnt >= g.game.fps * 5) _this.requestedNextScene.fire();
          };
        };

        DescriptionScene.prototype.timeoutHandler = function () {
          return function () {};
        };

        return DescriptionScene;
      }(SceneBase_1.SceneBase);

      exports.DescriptionScene = DescriptionScene;
    }, {
      "./SceneBase": 35
    }],
    14: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var assetInfo_1 = require("../assetInfo");

      var Needle_1 = require("../Needle");

      var WaitState_1 = require("../AnglerState/WaitState");

      var AnglerManager =
      /** @class */
      function () {
        function AnglerManager() {}

        AnglerManager.prototype.init = function (scene) {
          this.scene = scene;
          this.body = new g.Sprite(assetInfo_1.AssetInfo.getAnglerProperty(scene));
          this.line = new g.Sprite(assetInfo_1.AssetInfo.getLineProperty(scene));
          this.thunder = new g.FrameSprite(assetInfo_1.AssetInfo.getThunderProperty(scene));
          this.paralysisSound = scene.assets["paralysisSound"];
          this.needleCount = 0;
          this.needleMax = 5;
          this.needles = [];
          this.needlePosition = [290, 270, 250, 230, 210];
          this.newNeedleFlag = false;
          scene.append(this.thunder);
          this.thunder.start();
          this.thunder.hide();
          scene.append(this.body);
          scene.append(this.line);
          this.addNewNeedle();
          this.addNewNeedle();
          this.state = new WaitState_1.WaitState();
        };

        AnglerManager.getInstance = function () {
          if (!this.angler) this.angler = new this();
          return this.angler;
        };

        AnglerManager.prototype.getState = function () {
          return this.state;
        };

        AnglerManager.prototype.setState = function (state) {
          this.state = state;
        };

        AnglerManager.prototype.AnglerUpdate = function () {
          this.state.doAction(this);
          this.line.invalidate();
        };

        AnglerManager.prototype.moveNeedles = function (distance) {
          if (this.needleCount == 0) return;
          this.needles.forEach(function (needle) {
            needle.move(distance);
          });
        };

        AnglerManager.prototype.addNewNeedle = function () {
          if (this.needleCount >= this.needleMax) return;
          var newNeedle = new Needle_1.Needle(this.scene, this.needleCount % 2 == 0, this.needlePosition[this.needleCount]);
          this.needles.push(newNeedle);
          this.needleCount++;
          this.scene.append(newNeedle);
        };

        AnglerManager.prototype.onClick = function () {
          this.state.onClick(this);
        };

        return AnglerManager;
      }();

      exports.AnglerManager = AnglerManager;
    }, {
      "../AnglerState/WaitState": 10,
      "../Needle": 23,
      "../assetInfo": 42
    }],
    15: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var commonType_1 = require("../Common/commonType");

      var commonDefine_1 = require("../Common/commonDefine");

      var TimeManager_1 = require("./TimeManager");

      var FeverManager_1 = require("./FeverManager");

      var earlyDistribution = [{
        reikaInfo: commonDefine_1.commonDefine.UntiReika,
        number: 15
      }, {
        reikaInfo: commonDefine_1.commonDefine.HuwaReika,
        number: 25
      }, {
        reikaInfo: commonDefine_1.commonDefine.GyakuReika,
        number: 40
      }, {
        reikaInfo: commonDefine_1.commonDefine.YuReika,
        number: 45
      }, {
        reikaInfo: commonDefine_1.commonDefine.GataReika,
        number: 50
      }];
      var midDistribution = [{
        reikaInfo: commonDefine_1.commonDefine.UntiReika,
        number: 15
      }, {
        reikaInfo: commonDefine_1.commonDefine.YuReika,
        number: 30
      }, {
        reikaInfo: commonDefine_1.commonDefine.HuwaReika,
        number: 45
      }, {
        reikaInfo: commonDefine_1.commonDefine.GyakuReika,
        number: 50
      }, {
        reikaInfo: commonDefine_1.commonDefine.NemuReika,
        number: 55
      }, {
        reikaInfo: commonDefine_1.commonDefine.TakoReika,
        number: 70
      }];
      var lateDistribution = [{
        reikaInfo: commonDefine_1.commonDefine.UntiReika,
        number: 15
      }, {
        reikaInfo: commonDefine_1.commonDefine.YuReika,
        number: 35
      }, {
        reikaInfo: commonDefine_1.commonDefine.GyakuReika,
        number: 35
      }, {
        reikaInfo: commonDefine_1.commonDefine.NemuReika,
        number: 50
      }, {
        reikaInfo: commonDefine_1.commonDefine.TakoReika,
        number: 60
      }, {
        reikaInfo: commonDefine_1.commonDefine.YuiZarashi,
        number: 100
      }];
      var feverDistribution = [{
        reikaInfo: commonDefine_1.commonDefine.UntiReika,
        number: 20
      }, {
        reikaInfo: commonDefine_1.commonDefine.YuReika,
        number: 40
      }, {
        reikaInfo: commonDefine_1.commonDefine.OdoReika,
        number: 60
      }, {
        reikaInfo: commonDefine_1.commonDefine.GataReika,
        number: 70
      }, {
        reikaInfo: commonDefine_1.commonDefine.ReikaTyon,
        number: 90
      }, {
        reikaInfo: commonDefine_1.commonDefine.NemuReika,
        number: 100
      }];

      var DistributionManager =
      /** @class */
      function () {
        function DistributionManager() {
          this.state = commonType_1.DistributionState.EARLY;
          this.distribution = {
            "early": earlyDistribution,
            "mid": midDistribution,
            "late": lateDistribution,
            "fever": feverDistribution
          };
        }

        DistributionManager.getInstance = function () {
          if (!this._instance) this._instance = new DistributionManager();
          return this._instance;
        };

        DistributionManager.prototype.getCurrentDistribution = function () {
          switch (this.state) {
            case commonType_1.DistributionState.EARLY:
              return this.distribution["early"];

            case commonType_1.DistributionState.MID:
              return this.distribution["mid"];

            case commonType_1.DistributionState.LATE:
              return this.distribution["late"];

            case commonType_1.DistributionState.FEVER:
              return this.distribution["fever"];
          }
        };

        DistributionManager.prototype.updateState = function () {
          if (FeverManager_1.FeverManager.getInstance().isFeverMode()) {
            this.state = commonType_1.DistributionState.FEVER;
            return;
          }

          if (TimeManager_1.TimeManager.getInstance().getCurrentFrame() >= 20 * g.game.fps) this.state = commonType_1.DistributionState.MID;
          if (TimeManager_1.TimeManager.getInstance().getCurrentFrame() >= 50 * g.game.fps) this.state = commonType_1.DistributionState.LATE;
        };

        DistributionManager.prototype.getReikaInfo = function (random) {
          var length = Object.keys(this.getCurrentDistribution()).length;

          for (var i = 0; i < length; i++) {
            var distrInfo = this.getCurrentDistribution()[i];
            if (random < distrInfo.number) return distrInfo.reikaInfo;
          }

          return commonDefine_1.commonDefine.NormalReika;
        };

        return DistributionManager;
      }();

      exports.DistributionManager = DistributionManager;
    }, {
      "../Common/commonDefine": 11,
      "../Common/commonType": 12,
      "./FeverManager": 16,
      "./TimeManager": 19
    }],
    16: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var commonDefine_1 = require("../Common/commonDefine");

      var GAGE_SCALE_TIME = 15;

      var FeverManager =
      /** @class */
      function () {
        function FeverManager() {
          this.maxFeverPoint = 100;
        }

        FeverManager.getInstance = function () {
          if (!this.feverManager) this.feverManager = new this();
          return this.feverManager;
        };

        FeverManager.prototype.init = function (scene) {
          this.currentFeverPoint = 0;
          this.stack = 0;
          this.value = 0;
          this.feverMode = false;
          this.gageParent = new g.E({
            scene: scene,
            x: 280,
            y: 70,
            width: 344,
            height: 42
          });
          this.gage = new g.Sprite({
            scene: scene,
            src: scene.assets["gage"]
          });
          this.gaging = new g.Sprite({
            scene: scene,
            src: scene.assets["maxgage"],
            x: 5,
            y: 5
          });
          this.gageParent.append(this.gaging);
          this.gageParent.append(this.gage);
          scene.append(this.gageParent);
          this.initial_gage_length = this.gaging.width;
          this.gaging.width = 0;
          this.gaging.invalidate();
          this.bgm = scene.assets["bgm"];
          this.gata = scene.assets["getreika"];
          this.konoyaro = scene.assets["konoyaro"];
          this.reppu = scene.assets["reppu"];
          this.catchSE = scene.assets["catchSE"];
          this.catchFeverSE = scene.assets["catchFeverSE"];
        };

        FeverManager.prototype.playCatchSE = function () {
          this.catchSE.play();
        };

        FeverManager.prototype.playBGM = function () {
          this.bgm.stop();
          this.bgm.play();
        };

        FeverManager.prototype.stopBGM = function () {
          this.reppu.stop();
          this.bgm.stop();
        };

        FeverManager.prototype.playGetReikaSE = function () {
          if (!this.feverMode) {
            if (this.gata.inUse()) {
              this.gata.stop();
              this.gata.play();
            } else this.gata.play();
          } else {
            if (this.catchFeverSE.inUse()) {
              this.catchFeverSE.stop();
              this.catchFeverSE.play();
            } else this.catchFeverSE.play();
          }
        };

        FeverManager.prototype.plusFeverGage = function (point) {
          this.playGetReikaSE();
          this.startPlus(this.feverMode ? point / 3 : point);

          if (this.currentFeverPoint >= this.maxFeverPoint) {
            this.currentFeverPoint = this.maxFeverPoint;
            if (!this.feverMode) this.startFeverMode();
          }
        };

        FeverManager.prototype.minusFeverGage = function () {
          this.startPlus(-(this.feverMode ? 4 : 1));

          if (this.currentFeverPoint < 0) {
            this.currentFeverPoint = 0;
            if (this.feverMode) this.finishFeverMode();
          }
        };

        FeverManager.prototype.startFeverMode = function () {
          this.feverMode = true;
          this.bgm.stop();
          this.konoyaro.play();
          this.reppu.play();
        };

        FeverManager.prototype.finishFeverMode = function () {
          this.feverMode = false;
          this.reppu.stop();
          this.bgm.play();
        };

        FeverManager.prototype.isFeverMode = function () {
          return this.feverMode;
        };

        FeverManager.prototype.gageUpdate = function () {
          var feverrate = this.value / this.maxFeverPoint;
          this.gaging.width = this.initial_gage_length * feverrate;
          this.gaging.invalidate();
          this.animePlusGage();

          if (this.value < 0) {
            this.value = 0;
            this.stack = 0;
          } else if (this.value > this.maxFeverPoint) {
            this.value = this.maxFeverPoint;
            this.stack = 0;
          }
        };
        /**
         * スタックスコアからのマージスコアを一気に足す
         */


        FeverManager.prototype.mergeScore = function () {
          this.value += this.stack;
          this.stack = 0;
        };
        /**
         * スコア加算開始
         * @param {number} _plusScore 加算対象スコア
         */


        FeverManager.prototype.startPlus = function (_plusScore) {
          this.setStack(_plusScore);
          this.setPlus();
          this.currentFeverPoint += _plusScore;
        };
        /**
         * スコアをすこしずつ足す
         */


        FeverManager.prototype.animePlusGage = function () {
          if (this.stack > 0 && this.stack >= this.plus || this.stack < 0 && this.stack <= this.plus) {
            this.value += this.plus;
            this.stack -= this.plus;
          } else {
            this.mergeScore();
          }
        };
        /**
         * 加算幅をスタックスコアから設定
         */


        FeverManager.prototype.setPlus = function () {
          // ラベル強調時間で終わるように
          this.plus = this.stack / GAGE_SCALE_TIME;
        };
        /**
         * スコアを演出用にスタック
         * @param {number} _plusScore 加算対象スコア
         */


        FeverManager.prototype.setStack = function (_plusScore) {
          this.stack += _plusScore;
        };

        FeverManager.prototype.FeverMagnitudedParameter = function (parameter) {
          return this.feverMode ? parameter * commonDefine_1.commonDefine.FEVER_MAGNIFICATION : parameter;
        };

        return FeverManager;
      }();

      exports.FeverManager = FeverManager;
    }, {
      "../Common/commonDefine": 11
    }],
    17: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var ReikaBase_1 = require("../ReikaBase");

      var commonDefine_1 = require("../Common/commonDefine");

      var DistributionManager_1 = require("./DistributionManager");

      var GameScene_1 = require("../GameScene");

      var ReikaManager =
      /** @class */
      function () {
        function ReikaManager() {
          this.reikas = new Array();
        }

        ReikaManager.getInstance = function () {
          if (!this.reikaManager) this.reikaManager = new this();
          return this.reikaManager;
        };

        ReikaManager.prototype.registerReika = function (reika) {
          this.reikas.push(reika);
        };

        ReikaManager.prototype.unregisterReika = function (reika) {
          var index = this.reikas.indexOf(reika);
          this.reikas.splice(index, 1);
        };

        ReikaManager.prototype.update = function () {
          this.reikas.forEach(function (reika) {
            reika.move();
          });
        };

        ReikaManager.prototype.createReika = function (reikaInfo, scene) {
          var reika = this.getReikaFromName(scene, reikaInfo);
          var random = GameScene_1.GameScene.getRandom(0, commonDefine_1.commonDefine.SPAWN_RIGHT_ARRAY.length - 1);
          var isRight = GameScene_1.GameScene.getRandom(0, 1) == 0;
          reika.InitializePosition(isRight, random);
          return reika;
        };

        ReikaManager.prototype.getReikaFromName = function (scene, reikaInfo) {
          var reika;

          switch (reikaInfo.swim_src) {
            case "gatareika":
              reika = new ReikaBase_1.GataReika(scene, reikaInfo);
              break;

            case "normal":
              reika = new ReikaBase_1.NormalReika(scene, reikaInfo);
              break;

            case "nemureika":
              reika = new ReikaBase_1.NemuReika(scene, reikaInfo);
              break;

            case "takoreika":
              reika = new ReikaBase_1.TakoReika(scene, reikaInfo);
              break;

            case "yureika":
              reika = new ReikaBase_1.YuReika(scene, reikaInfo);
              break;

            case "yuizarashi2":
              reika = new ReikaBase_1.YuiZarashi(scene, reikaInfo);
              break;

            case "untireika":
              reika = new ReikaBase_1.UntiReika(scene, reikaInfo);
              break;

            default:
              reika = new ReikaBase_1.ReikaBase(scene, reikaInfo);
              break;
          }

          return reika;
        };

        ReikaManager.prototype.spawn = function (scene) {
          if (Object.keys(this.reikas).length > commonDefine_1.commonDefine.MAX_REIKA_POOL) return;
          var random = GameScene_1.GameScene.getRandom(0, 99);
          var reikaInfo = DistributionManager_1.DistributionManager.getInstance().getReikaInfo(random);
          var reika = this.createReika(reikaInfo, scene);
          scene.append(reika);
        };

        return ReikaManager;
      }();

      exports.ReikaManager = ReikaManager;
    }, {
      "../Common/commonDefine": 11,
      "../GameScene": 20,
      "../ReikaBase": 24,
      "./DistributionManager": 15
    }],
    18: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var gameUtil_1 = require("../Util/gameUtil");

      var define_1 = require("../define");

      var entityUtil_1 = require("../Util/entityUtil");

      var tl = require("@akashic-extension/akashic-timeline");

      var FeverManager_1 = require("./FeverManager");

      var InstantScoreViewer_1 = require("../InstantScoreViewer");
      /** スコア強調時間：OFF→ON */


      var SCORE_TIME_ON = 3;
      /** スコア強調時間：ON→OFF */

      var SCORE_TIME_OFF = 7;
      /** スコア強調スケール：OFF→ON */

      var SCORE_SCALE_ON = 1.1;
      /** スコア強調スケール：ON→OFF */

      var SCORE_SCALE_OFF = 1.0;
      /** スコア強調時移動調整距離 */

      var SCORE_SCALE_MOVE_X = 8;
      var SCORE_X = 380;
      var SCORE_Y = 20;

      var ScoreManager =
      /** @class */
      function () {
        function ScoreManager() {
          /** ラベル初期位置 */
          this.posLabelStart = null;
          /** 現在のスコア */

          this.value = null;
          /** スコア加算演出用スタック */

          this.stack = null;
          /** 加算幅 */

          this.plus = null;
        }

        ScoreManager.getInstance = function () {
          if (!this.scoreManager) this.scoreManager = new this();
          return this.scoreManager;
        };

        ScoreManager.prototype.displayScore = function () {
          entityUtil_1.entityUtil.setLabelText(this.scoreLabel, String(g.game.vars.gameState.score));
        };

        ScoreManager.prototype.init = function (scene) {
          this.scoreLabel = entityUtil_1.entityUtil.createWhiteLabel(6, {
            x: SCORE_X,
            y: SCORE_Y
          }, scene);
          this.timeline = new tl.Timeline(scene);
          this.posLabelStart = {
            x: this.scoreLabel.x,
            y: this.scoreLabel.y
          };
          this.ptSprite = new g.Sprite({
            scene: scene,
            src: g.game.scene().assets["pt"],
            x: SCORE_X + 40,
            y: SCORE_Y
          });
          this.instantScoreViewer = new InstantScoreViewer_1.InstantScoreViewer(scene);
          this.value = 0;
          this.stack = 0;
          entityUtil_1.entityUtil.appendEntity(this.ptSprite, scene);
          entityUtil_1.entityUtil.setLabelText(this.scoreLabel, String(this.value));
        };
        /**
         * ラベルテキストの更新
         */


        ScoreManager.prototype.onUpdate = function () {
          entityUtil_1.entityUtil.setLabelText(this.scoreLabel, String(this.value));
          this.animePlusScore();

          if (this.value < 0) {
            this.value = 0;
            this.stack = 0;
            gameUtil_1.gameUtil.updateGameStateScore(this.value);
          } else if (this.value > define_1.define.SCORE_LIMIT) {
            this.value = define_1.define.SCORE_LIMIT;
            this.stack = 0;
            gameUtil_1.gameUtil.updateGameStateScore(this.value);
          }
        };
        /**
         * スコアのgetter
         * @return {number} スコア
         */


        ScoreManager.prototype.getValue = function () {
          return this.value;
        };
        /**
         * スタックスコアからのマージスコアを一気に足す
         */


        ScoreManager.prototype.mergeScore = function () {
          this.value += this.stack;
          this.stack = 0;
        };
        /**
         * スコア加算開始
         * @param {number} _plusScore 加算対象スコア
         */


        ScoreManager.prototype.startPlus = function (_plusScore) {
          var plusScore = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(_plusScore);
          this.instantScoreViewer.pushNumber(plusScore);
          this.setStack(plusScore);
          this.setPlus();
          this.setTween();
          gameUtil_1.gameUtil.updateGameStateScore(this.value + this.stack);
        };
        /**
         * ゲーム終了時の処理まとめ
         */


        ScoreManager.prototype.onFinishGame = function () {
          this.mergeScore(); // 残ったスタックスコアを加算

          this.onUpdate();
          gameUtil_1.gameUtil.updateGameStateScore(this.value + this.stack);
        };
        /**
         * スコアをすこしずつ足す
         */


        ScoreManager.prototype.animePlusScore = function () {
          if (this.stack > 0 && this.stack >= this.plus) {
            this.value += this.plus;
            this.stack -= this.plus;
          } else {
            this.mergeScore();
          }
        };
        /**
         * 加算幅をスタックスコアから設定
         */


        ScoreManager.prototype.setPlus = function () {
          // ラベル強調時間で終わるように
          this.plus = Math.floor(this.stack / (SCORE_TIME_ON + SCORE_TIME_OFF));
        };
        /**
         * スコアを演出用にスタック
         * @param {number} _plusScore 加算対象スコア
         */


        ScoreManager.prototype.setStack = function (_plusScore) {
          this.stack += _plusScore;
        };
        /**
         * 加算時に強調する演出tween設定
         */


        ScoreManager.prototype.setTween = function () {
          var scaleOff = SCORE_SCALE_OFF; // 縮小倍率 =原寸大

          var scaleOn = SCORE_SCALE_ON; // 拡大倍率 スコア桁数によって調整したい

          var fps = g.game.scene().game.fps;
          var mSec = 1000;
          var timeScaleOffInit = 1 * mSec / fps; // 初期化縮小にかけるミリ秒

          var timeScaleOn = SCORE_TIME_ON * mSec / fps; // 巨大化にかけるミリ秒

          var timeScaleOff = SCORE_TIME_OFF * mSec / fps; // 縮小にかけるミリ秒

          this.timeline.clear(); // 毎回作り直し

          var tween = this.timeline.create(this.scoreLabel, {
            modified: this.scoreLabel.modified,
            destroyed: this.scoreLabel.destroyed
          }); // tweenが重なった場合、まず元のサイズに

          tween.to({
            scaleX: scaleOff,
            scaleY: scaleOff
          }, timeScaleOffInit);
          tween.con(); // 上下処理結合

          tween.moveTo( // 位置をもとに戻す
          this.posLabelStart.x, this.posLabelStart.y, timeScaleOffInit);
          tween.to({
            scaleX: scaleOn,
            scaleY: scaleOn
          }, timeScaleOn); // 強調開始

          tween.con(); // 上下処理結合

          tween.moveTo( // 原点の問題上ずれるので調整用 計算で調整幅出したい
          this.posLabelStart.x - SCORE_SCALE_MOVE_X, this.posLabelStart.y, timeScaleOn);
          tween.to({
            scaleX: scaleOff,
            scaleY: scaleOff
          }, timeScaleOff); // 強調終了

          tween.con(); // 上下処理結合

          tween.moveTo( // 位置をもとに戻す
          this.posLabelStart.x, this.posLabelStart.y, timeScaleOff);
        };

        return ScoreManager;
      }();

      exports.ScoreManager = ScoreManager;
    }, {
      "../InstantScoreViewer": 21,
      "../Util/entityUtil": 40,
      "../Util/gameUtil": 41,
      "../define": 43,
      "./FeverManager": 16,
      "@akashic-extension/akashic-timeline": 5
    }],
    19: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var DistributionManager_1 = require("./DistributionManager");

      var commonDefine_1 = require("../Common/commonDefine");

      var entityUtil_1 = require("../Util/entityUtil");

      var ReadyState_1 = require("../TimeState/ReadyState");

      var FeverManager_1 = require("./FeverManager");

      var ScoreManager_1 = require("./ScoreManager");

      var AnglerManager_1 = require("./AnglerManager");

      var ReikaManager_1 = require("./ReikaManager");

      var tl = require("@akashic-extension/akashic-timeline");

      var TimeManager =
      /** @class */
      function () {
        function TimeManager() {}

        TimeManager.getInstance = function () {
          if (!this.timeManager) this.timeManager = new this();
          return this.timeManager;
        };

        TimeManager.prototype.init = function (scene) {
          this.scene = scene;
          this.frameCount = 0;
          this.timerLabel = new TimerLabel(scene);
          this.timerLabel.setText(String(this.remainTime()));
          this.time = new g.Sprite({
            scene: scene,
            src: scene.assets["time"],
            x: commonDefine_1.commonDefine.TIME_X - 70,
            y: 15
          });
          this.state = new ReadyState_1.ReadyState(scene);
          entityUtil_1.entityUtil.appendEntity(this.time, scene);
        };

        TimeManager.prototype.frame2Sec = function () {
          return this.frameCount / g.game.fps;
        };

        TimeManager.prototype.getPlaySec = function () {
          return Math.floor(this.frame2Sec());
        };

        TimeManager.prototype.getCurrentFrame = function () {
          return this.frameCount;
        };

        TimeManager.prototype.remainTime = function () {
          var remain = Math.floor(commonDefine_1.commonDefine.GAME_OVER_TIME / 1000 - this.getPlaySec());
          return remain >= 0 ? remain : 0;
        };

        TimeManager.prototype.updateTime = function () {
          this.frameCount += 1;
          this.state.doAction(this);
        };

        TimeManager.prototype.setState = function (state) {
          this.state = state;
        };

        TimeManager.prototype.setInterval = function (updator, intervalSec) {
          if (this.frameCount % (g.game.fps * intervalSec) == 0) updator();
        };

        TimeManager.prototype.gameUpdate = function () {
          var _this = this;

          FeverManager_1.FeverManager.getInstance().gageUpdate();
          DistributionManager_1.DistributionManager.getInstance().updateState();
          ScoreManager_1.ScoreManager.getInstance().onUpdate();
          AnglerManager_1.AnglerManager.getInstance().AnglerUpdate();
          ReikaManager_1.ReikaManager.getInstance().update();
          this.setInterval(function () {
            ReikaManager_1.ReikaManager.getInstance().spawn(_this.scene);
          }, commonDefine_1.commonDefine.SPAWN_INTERVAL / FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(1));
          this.setInterval(function () {
            FeverManager_1.FeverManager.getInstance().minusFeverGage();
          }, 0.5);
          this.timerLabel.setText(String(this.remainTime()));
        };

        return TimeManager;
      }();

      exports.TimeManager = TimeManager;

      var TimerLabel =
      /** @class */
      function () {
        function TimerLabel(scene) {
          this.normalLabel = entityUtil_1.entityUtil.createWhiteLabel(6, {
            x: commonDefine_1.commonDefine.TIME_X,
            y: commonDefine_1.commonDefine.TIME_Y
          }, scene);
          this.emergencyLabel = entityUtil_1.entityUtil.createRedLabel(6, {
            x: commonDefine_1.commonDefine.TIME_X,
            y: commonDefine_1.commonDefine.TIME_Y
          }, scene);
          this.emergencyLabel.hide();
          this.currentLabel = this.normalLabel;
          this.timeline = new tl.Timeline(scene);
        }

        TimerLabel.prototype.setText = function (text) {
          entityUtil_1.entityUtil.setLabelText(this.currentLabel, text);
        };

        TimerLabel.prototype.changeState = function () {
          this.normalLabel.hide();
          this.currentLabel = this.emergencyLabel;
          entityUtil_1.entityUtil.setLabelText(this.currentLabel, this.normalLabel.text);
          this.emergencyLabel.show();
          this.alertAnimation();
        };

        TimerLabel.prototype.alertAnimation = function () {
          this.timeline.clear();
          var tween = this.timeline.create(this.emergencyLabel, {
            modified: this.emergencyLabel.invalidate,
            destroyed: this.emergencyLabel.destroyed
          });
          tween.to({
            scaleX: 1.5,
            scaleY: 1.5
          }, 500);
          tween.con();
          tween.moveBy(-25, 0, 500);
          tween.to({
            scaleX: 1.0,
            scaleY: 1.0
          }, 500);
          tween.con();
          tween.moveBy(25, 0, 500);
        };

        return TimerLabel;
      }();

      exports.TimerLabel = TimerLabel;
    }, {
      "../Common/commonDefine": 11,
      "../TimeState/ReadyState": 38,
      "../Util/entityUtil": 40,
      "./AnglerManager": 14,
      "./DistributionManager": 15,
      "./FeverManager": 16,
      "./ReikaManager": 17,
      "./ScoreManager": 18,
      "@akashic-extension/akashic-timeline": 5
    }],
    20: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SceneBase_1 = require("./SceneBase");

      var FeverManager_1 = require("./GameManager/FeverManager");

      var TimeManager_1 = require("./GameManager/TimeManager");

      var ScoreManager_1 = require("./GameManager/ScoreManager");

      var AnglerManager_1 = require("./GameManager/AnglerManager");

      var assetInfo_1 = require("./assetInfo");

      var GameScene =
      /** @class */
      function (_super) {
        __extends(GameScene, _super);

        function GameScene(property) {
          return _super.call(this, property) || this;
        }

        GameScene.getRandom = function (min, max) {
          if (this.random == null) this.random = new g.XorshiftRandomGenerator(new Date().getSeconds());
          return this.random.get(min, max);
        };

        GameScene.prototype.loadedHandler = function () {
          var _this = this;

          return function () {
            g.game.vars.gameState = {
              score: 0
            };
            var bg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#aaccff",
              opacity: 0.4
            });

            _this.append(bg);

            _this.alertBG = new g.Sprite({
              scene: _this,
              src: _this.assets["alertBG"],
              x: 0,
              y: 0,
              opacity: 0
            });

            _this.append(_this.alertBG);

            FeverManager_1.FeverManager.getInstance().init(_this);
            ScoreManager_1.ScoreManager.getInstance().init(_this);
            TimeManager_1.TimeManager.getInstance().init(_this);
            AnglerManager_1.AnglerManager.getInstance().init(_this);
            _this.wave = new g.FrameSprite(assetInfo_1.AssetInfo.getWaveProperty(_this));

            _this.append(_this.wave);

            _this.wave.start();

            _this.sun = new g.FrameSprite(assetInfo_1.AssetInfo.getSunProperty(_this));

            _this.append(_this.sun);

            _this.sun.start();

            _this.pointDownCapture.handle(function () {
              AnglerManager_1.AnglerManager.getInstance().onClick();
            });
          };
        };

        GameScene.prototype.updateHandler = function () {
          return function () {
            TimeManager_1.TimeManager.getInstance().updateTime();
          };
        };

        GameScene.prototype.timeoutHandler = function () {
          return function () {};
        };

        GameScene.prototype.destroy = function () {
          FeverManager_1.FeverManager.getInstance().stopBGM();

          _super.prototype.destroy.call(this);
        };

        return GameScene;
      }(SceneBase_1.SceneBase);

      exports.GameScene = GameScene;
    }, {
      "./GameManager/AnglerManager": 14,
      "./GameManager/FeverManager": 16,
      "./GameManager/ScoreManager": 18,
      "./GameManager/TimeManager": 19,
      "./SceneBase": 35,
      "./assetInfo": 42
    }],
    21: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var MotionLabel_1 = require("./MotionLabel");

      var entityUtil_1 = require("./Util/entityUtil");

      var InstantScoreViewer =
      /** @class */
      function () {
        function InstantScoreViewer(scene) {
          this.DISPLAY_TIME = 2000;
          this.displayX = 250;
          this.pointStack = [];
          this.labelStack = [];
          this.labelStack.push(new MotionLabel_1.MotionLabel(entityUtil_1.entityUtil.createRedLabel(6, {
            x: 240,
            y: 80
          }, scene)));
          this.labelStack[0].setStartPos(this.displayX, 80);
          this.labelStack.push(new MotionLabel_1.MotionLabel(entityUtil_1.entityUtil.createRedLabel(6, {
            x: 240,
            y: 100
          }, scene)));
          this.labelStack[1].setStartPos(this.displayX, 100);
          this.labelStack.push(new MotionLabel_1.MotionLabel(entityUtil_1.entityUtil.createRedLabel(6, {
            x: 240,
            y: 100
          }, scene)));
          this.labelStack[2].setStartPos(this.displayX, 100);
          this.labelStack.push(new MotionLabel_1.MotionLabel(entityUtil_1.entityUtil.createRedLabel(6, {
            x: 240,
            y: 100
          }, scene)));
          this.labelStack[3].setStartPos(this.displayX, 100);
          this.labelStack.push(new MotionLabel_1.MotionLabel(entityUtil_1.entityUtil.createRedLabel(6, {
            x: 240,
            y: 100
          }, scene)));
          this.labelStack[4].setStartPos(this.displayX, 100);

          for (var i = 0; i < 4; i++) {
            this.labelStack[i].setNext(this.labelStack[i + 1]);
          }

          this.resetLabelPosition();
        }

        InstantScoreViewer.prototype.start = function () {
          var _this = this;

          var i = 0;
          this.pointStack.forEach(function (point) {
            _this.labelStack[i].setPoint(point);

            i++;
          });
          this.resetLabelPosition();
          MotionLabel_1.MotionLabel.duration = this.DISPLAY_TIME / Object.keys(this.pointStack).length;
          this.pointStack = [];
          this.labelStack[0].startAnimation();
        };

        InstantScoreViewer.prototype.pushNumber = function (point) {
          this.pointStack.push(point);
        };

        InstantScoreViewer.prototype.resetLabelPosition = function () {
          this.labelStack.forEach(function (label) {
            label.resetPosition();
          });
        };

        return InstantScoreViewer;
      }();

      exports.InstantScoreViewer = InstantScoreViewer;
    }, {
      "./MotionLabel": 22,
      "./Util/entityUtil": 40
    }],
    22: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var tl = require("@akashic-extension/akashic-timeline");

      var entityUtil_1 = require("./Util/entityUtil");

      var MotionLabel =
      /** @class */
      function () {
        function MotionLabel(label) {
          this.label = label;
          this.next = null;
          this.timeline = new tl.Timeline(this.label.scene);
          this.isEnable = false;
          this.startPosX = label.x;
          this.startPosY = label.y;
        }

        MotionLabel.prototype.setStartPos = function (x, y) {
          this.startPosX = x;
          this.startPosY = y;
          this.resetPosition();
        };

        MotionLabel.prototype.IsEnable = function () {
          return this.isEnable;
        };

        MotionLabel.prototype.setNext = function (next) {
          this.next = next;
        };

        MotionLabel.prototype.setPoint = function (point) {
          this.point = point;
          entityUtil_1.entityUtil.setLabelText(this.label, "+" + this.point.toString());
          this.isEnable = true;
        };

        MotionLabel.prototype.startAnimation = function () {
          var _this = this;

          if (!this.IsEnable()) return;
          this.label.show();
          this.timeline.clear();
          var tween = this.timeline.create(this.label, {
            modified: this.label.invalidate,
            destroyed: this.label.destroyed
          });
          tween.fadeIn(MotionLabel.duration / 4);
          tween.con();
          tween.moveTo(this.destX, this.destY, MotionLabel.duration / 4);
          tween.to({
            scaleX: 1.2,
            scaleY: 1.2
          }, MotionLabel.duration / 4);
          tween.call(function () {
            if (_this.next == null) return;

            _this.next.startAnimation();
          });
          tween.to({
            scaleX: 1.0,
            scaleY: 1.0
          }, MotionLabel.duration / 3);
          tween.con();
          tween.fadeOut(MotionLabel.duration / 3);
          this.isEnable = false;
        };

        MotionLabel.prototype.resetPosition = function () {
          this.label.x = this.getX();
          this.label.y = this.startPosY;
          this.destX = this.label.x;
          this.destY = 70;
          this.label.hide();
          this.label.invalidate();
        };

        MotionLabel.prototype.getX = function () {
          if (this.point < 1000) return this.startPosX - 60;else if (this.point < 10000) return this.startPosX - 30;else return this.startPosX;
        };

        return MotionLabel;
      }();

      exports.MotionLabel = MotionLabel;
    }, {
      "./Util/entityUtil": 40,
      "@akashic-extension/akashic-timeline": 5
    }],
    23: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var ReikaBase_1 = require("./ReikaBase");

      var FeverManager_1 = require("./GameManager/FeverManager");

      var Needle =
      /** @class */
      function (_super) {
        __extends(Needle, _super);

        function Needle(scene, isRight, y) {
          var _this = _super.call(this, {
            scene: scene,
            src: isRight ? scene.assets["needle"] : scene.assets["needle2"],
            x: isRight ? 230 + 0 : 230 - 50,
            y: y
          }) || this;

          _this.isRight = isRight;
          _this.isEmpty = true;
          _this.collisionArea = {
            x: isRight ? _this.x + 40 : _this.x + 10,
            y: _this.y + 40,
            width: 10,
            height: 10
          };
          _this.collisionRect = new g.E({
            scene: scene,
            x: _this.collisionArea.x,
            y: _this.collisionArea.y,
            width: _this.collisionArea.width,
            height: _this.collisionArea.height,
            opacity: 0
          });
          scene.append(_this.collisionRect);
          return _this;
        }

        Needle.prototype.move = function (distance) {
          this.y += distance;
          this.collisionRect.y += distance;
        };

        Needle.prototype.searchReika = function () {
          if (this.isEmpty) {
            for (var i = 0; i < this.scene.children.length; i++) {
              var currentChild = this.scene.children[i];
              if (currentChild instanceof ReikaBase_1.ReikaBase && currentChild.isCatchable() && g.Collision.intersectAreas(this.collisionRect, currentChild)) this.catchReika(currentChild);
            }
          }
        };

        Needle.prototype.catchReika = function (reika) {
          if (!this.isEmpty) return;
          FeverManager_1.FeverManager.getInstance().playCatchSE();
          this.isEmpty = false;
          reika.changeCaughtState();
          reika.y = reika.width * 0.2;

          if (this.isRight) {
            reika.x = this.width - reika.width * 0.2;
            reika.angle = 30;
          } else {
            reika.x = -reika.width * 0.8;
            reika.angle = 330;
          }

          this.append(reika);
        };

        Needle.prototype.reset = function () {
          if (!this.isEmpty) this.children.forEach(function (reika) {
            reika.destroy();
          });
          this.isEmpty = true;
        };

        Needle.prototype.getCaughtReikaName = function () {
          if (this.isEmpty) return null;
          return this.children[0].getName();
        };

        Needle.prototype.addScoreAndFever = function () {
          if (!this.isEmpty) this.children.forEach(function (reika) {
            reika.plusScoreAndFever();
          });
        };

        Object.defineProperty(Needle.prototype, "IsEmpty", {
          get: function get() {
            return this.isEmpty;
          },
          enumerable: true,
          configurable: true
        });
        return Needle;
      }(g.Sprite);

      exports.Needle = Needle;
    }, {
      "./GameManager/FeverManager": 16,
      "./ReikaBase": 24
    }],
    24: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var commonDefine_1 = require("./Common/commonDefine");

      var entityUtil_1 = require("./Util/entityUtil");

      var ScoreManager_1 = require("./GameManager/ScoreManager");

      var FeverManager_1 = require("./GameManager/FeverManager");

      var ReikaManager_1 = require("./GameManager/ReikaManager");

      var SwimState_1 = require("./ReikaState/SwimState");

      var CatchState_1 = require("./ReikaState/CatchState");

      var DirectionalSwimState_1 = require("./ReikaState/DirectionalSwimState");

      var RollingState_1 = require("./ReikaState/RollingState");

      var VibrateSwimState_1 = require("./ReikaState/VibrateSwimState");

      var VibrateCatchState_1 = require("./ReikaState/VibrateCatchState");

      var UntiReikaState_1 = require("./ReikaState/UntiReikaState");

      var DirectionalMotionSwimState_1 = require("./ReikaState/DirectionalMotionSwimState");

      var ReikaBase =
      /** @class */
      function (_super) {
        __extends(ReikaBase, _super);

        function ReikaBase(scene, reikaInfo) {
          var _this = this;

          var src = scene.assets[reikaInfo.swim_src];
          var height = src.height;
          var width = src.width;
          _this = _super.call(this, {
            scene: scene,
            src: src,
            width: width,
            height: height,
            srcWidth: width,
            srcHeight: height
          }) || this;
          _this.reikaInfo = reikaInfo;
          _this.frame = 0;
          _this.reikaState = new SwimState_1.SwimState();
          _this.catchState = new CatchState_1.CatchState();
          ReikaManager_1.ReikaManager.getInstance().registerReika(_this);
          return _this;
        }

        ReikaBase.prototype.InitializePosition = function (isRight, random) {
          this.isRight = isRight;
          this.x = isRight ? g.game.width : -this.width;
          this.initialY = isRight ? commonDefine_1.commonDefine.SPAWN_RIGHT_ARRAY[random] : commonDefine_1.commonDefine.SPAWN_LEFT_ARRAY[random];
          this.y = this.initialY;
          this.scaleX = this.isRight ? -1 : 1;
          this.modified();
        };

        ReikaBase.prototype.move = function () {
          this.frame++;
          this.reikaState.doAction(this);
        };

        ReikaBase.prototype.plusScoreAndFever = function () {
          FeverManager_1.FeverManager.getInstance().plusFeverGage(12);
          ScoreManager_1.ScoreManager.getInstance().startPlus(this.reikaInfo.point);
        };

        ReikaBase.prototype.getPoint = function () {
          return this.reikaInfo.point;
        };

        ReikaBase.prototype.getName = function () {
          return this.reikaInfo.swim_src;
        };

        ReikaBase.prototype.changeCaughtState = function () {
          this.stop();
          this.reikaState = this.catchState;
          entityUtil_1.entityUtil.changeSpriteSurface(this, this.scene.assets[this.reikaInfo.caught_src]);
        };

        ReikaBase.prototype.getCenterX = function () {
          return this.x + this.width / 2;
        };

        ReikaBase.prototype.getCenterY = function () {
          return this.y + this.height / 2;
        };

        ReikaBase.prototype.isCatchable = function () {
          return this.reikaState.isCatchable;
        };

        ReikaBase.prototype.destroy = function () {
          ReikaManager_1.ReikaManager.getInstance().unregisterReika(this);

          _super.prototype.destroy.call(this);
        };

        return ReikaBase;
      }(g.FrameSprite);

      exports.ReikaBase = ReikaBase;

      var GataReika =
      /** @class */
      function (_super) {
        __extends(GataReika, _super);

        function GataReika(scene, reikaInfo) {
          var _this = _super.call(this, scene, reikaInfo) || this;

          _this.reikaState = new VibrateSwimState_1.VibrateSwimState();
          _this.catchState = new VibrateCatchState_1.VibrateCatchState();
          return _this;
        }

        return GataReika;
      }(ReikaBase);

      exports.GataReika = GataReika;

      var NormalReika =
      /** @class */
      function (_super) {
        __extends(NormalReika, _super);

        function NormalReika(scene, reikaInfo) {
          var _this = _super.call(this, scene, reikaInfo) || this;

          _this.width = 120;
          _this.height = 60;
          _this.srcWidth = 120;
          _this.srcHeight = 60;
          _this.interval = 100;
          _this.frames = [0, 1, 2, 3];
          _this.reikaState = new DirectionalSwimState_1.DirectionalSwimState();

          _this.modified();

          return _this;
        }

        return NormalReika;
      }(ReikaBase);

      exports.NormalReika = NormalReika;

      var TakoReika =
      /** @class */
      function (_super) {
        __extends(TakoReika, _super);

        function TakoReika(scene, reikaInfo) {
          var _this = _super.call(this, scene, reikaInfo) || this;

          var scale = 1.2;
          _this.width = 240 * scale;
          _this.height = 60 * scale;
          _this.srcWidth = 240;
          _this.srcHeight = 60;
          _this.loop = false;
          _this.interval = 100;

          _this.modified();

          return _this;
        }

        return TakoReika;
      }(NormalReika);

      exports.TakoReika = TakoReika;

      var YuReika =
      /** @class */
      function (_super) {
        __extends(YuReika, _super);

        function YuReika(scene, reikaInfo) {
          var _this = _super.call(this, scene, reikaInfo) || this;

          var scale = 1.2;
          _this.width = 240 * scale;
          _this.height = 60 * scale;
          _this.srcWidth = 240;
          _this.srcHeight = 60;
          _this.loop = false;
          _this.interval = 100;

          _this.modified();

          return _this;
        }

        return YuReika;
      }(NormalReika);

      exports.YuReika = YuReika;

      var YuiZarashi =
      /** @class */
      function (_super) {
        __extends(YuiZarashi, _super);

        function YuiZarashi(scene, reikaInfo) {
          var _this = _super.call(this, scene, reikaInfo) || this;

          var scale = 1.2;
          _this.width = 240 * scale;
          _this.height = 60 * scale;
          _this.srcWidth = 240;
          _this.srcHeight = 60;
          _this.loop = true;
          _this.interval = 300;
          _this.frames = [0, 1, 2, 3];

          _this.modified();

          _this.reikaState = new DirectionalMotionSwimState_1.DirectionalMotionSwimState();

          _this.start();

          return _this;
        }

        YuiZarashi.prototype.InitializePosition = function (isRight, random) {
          _super.prototype.InitializePosition.call(this, isRight, random);

          this.scaleX = this.isRight ? 1 : -1;
          this.modified();
        };

        YuiZarashi.prototype.changeCaughtState = function () {
          this.reikaState = this.catchState;
          this.frames = [0, 1, 2, 3];
          this.interval = 100;
          this.modified();
          this.start();
        };

        return YuiZarashi;
      }(NormalReika);

      exports.YuiZarashi = YuiZarashi;

      var NemuReika =
      /** @class */
      function (_super) {
        __extends(NemuReika, _super);

        function NemuReika(scene, reikaInfo) {
          var _this = _super.call(this, scene, reikaInfo) || this;

          _this.width = 140;
          _this.height = 60;
          _this.srcWidth = 140;
          _this.srcHeight = 60;
          _this.frames = [0, 1, 2, 3];
          _this.interval = 300;

          _this.modified();

          _this.reikaState = new RollingState_1.RollingState();

          _this.start();

          return _this;
        }

        NemuReika.prototype.changeCaughtState = function () {
          this.reikaState = this.catchState;
        };

        return NemuReika;
      }(ReikaBase);

      exports.NemuReika = NemuReika;

      var UntiReika =
      /** @class */
      function (_super) {
        __extends(UntiReika, _super);

        function UntiReika(scene, reikaInfo) {
          var _this = _super.call(this, scene, reikaInfo) || this;

          _this.width = 300;
          _this.height = 60;
          _this.srcWidth = 300;
          _this.srcHeight = 60;
          _this.loop = false;
          _this.interval = 100;
          _this.reikaState = new UntiReikaState_1.SwimUntiState();

          _this.modified();

          return _this;
        }

        UntiReika.prototype.InitializePosition = function (isRight, random) {
          this.isRight = isRight;
          this.x = isRight ? g.game.width : -this.width;
          this.initialY = isRight ? commonDefine_1.commonDefine.SPAWN_RIGHT_ARRAY[random] : commonDefine_1.commonDefine.SPAWN_LEFT_ARRAY[random];
          this.y = this.initialY;
          this.scaleX = this.isRight ? -1 : 1;
          this.modified();
        };

        return UntiReika;
      }(ReikaBase);

      exports.UntiReika = UntiReika;

      var Unti =
      /** @class */
      function (_super) {
        __extends(Unti, _super);

        function Unti() {
          return _super !== null && _super.apply(this, arguments) || this;
        }

        return Unti;
      }(ReikaBase);

      exports.Unti = Unti;
    }, {
      "./Common/commonDefine": 11,
      "./GameManager/FeverManager": 16,
      "./GameManager/ReikaManager": 17,
      "./GameManager/ScoreManager": 18,
      "./ReikaState/CatchState": 25,
      "./ReikaState/DirectionalMotionSwimState": 26,
      "./ReikaState/DirectionalSwimState": 27,
      "./ReikaState/RollingState": 29,
      "./ReikaState/SwimState": 30,
      "./ReikaState/UntiReikaState": 31,
      "./ReikaState/VibrateCatchState": 32,
      "./ReikaState/VibrateSwimState": 33,
      "./Util/entityUtil": 40
    }],
    25: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var ReikaStateBase_1 = require("./ReikaStateBase");

      var CatchState =
      /** @class */
      function (_super) {
        __extends(CatchState, _super);

        function CatchState() {
          var _this = _super.call(this) || this;

          _this.isCatchable = false;
          return _this;
        }

        CatchState.prototype.doAction = function (reikaBase) {
          reikaBase.invalidate();
        };

        return CatchState;
      }(ReikaStateBase_1.ReikaStateBase);

      exports.CatchState = CatchState;
    }, {
      "./ReikaStateBase": 28
    }],
    26: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SwimState_1 = require("./SwimState");

      var GameScene_1 = require("../GameScene");

      var State;

      (function (State) {
        State[State["SWIM"] = 0] = "SWIM";
        State[State["TURN"] = 1] = "TURN";
      })(State || (State = {}));

      ;

      var DirectionalMotionSwimState =
      /** @class */
      function (_super) {
        __extends(DirectionalMotionSwimState, _super);

        function DirectionalMotionSwimState() {
          var _this = _super.call(this) || this;

          _this.state = State.SWIM;
          return _this;
        }

        DirectionalMotionSwimState.prototype.doAction = function (reikaBase) {
          switch (this.state) {
            case State.SWIM:
              if (reikaBase.frame % 30 == 0 && GameScene_1.GameScene.getRandom(0, 10) == 0) this.changeDirection(reikaBase);
              break;

            case State.TURN:
              if (reikaBase.frameNumber == 3) this.animationFinished = true;

              if (reikaBase.frameNumber == 0 && this.animationFinished) {
                reikaBase.scaleX = reikaBase.isRight ? 1 : -1;
                reikaBase.stop();
                reikaBase.frames = [0, 1, 2, 3];
                reikaBase.interval = 300;
                reikaBase.modified();
                reikaBase.start();
                this.state = State.SWIM;
              }

              break;
          }

          _super.prototype.doAction.call(this, reikaBase);
        };

        DirectionalMotionSwimState.prototype.changeDirection = function (reikaBase) {
          reikaBase.interval = 100;
          reikaBase.frames = [4, 5, 6, 7];
          reikaBase.modified();
          reikaBase.start();
          reikaBase.isRight = !reikaBase.isRight;
          this.state = State.TURN;
          this.animationFinished = false;
        };

        return DirectionalMotionSwimState;
      }(SwimState_1.SwimState);

      exports.DirectionalMotionSwimState = DirectionalMotionSwimState;
    }, {
      "../GameScene": 20,
      "./SwimState": 30
    }],
    27: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SwimState_1 = require("./SwimState");

      var GameScene_1 = require("../GameScene");

      var DirectionalSwimState =
      /** @class */
      function (_super) {
        __extends(DirectionalSwimState, _super);

        function DirectionalSwimState() {
          var _this = _super.call(this) || this;

          _this.animationFinished = true;
          return _this;
        }

        DirectionalSwimState.prototype.doAction = function (reikaBase) {
          if (reikaBase.frameNumber == 3) this.animationFinished = true;

          if (reikaBase.frameNumber == 0 && this.animationFinished) {
            reikaBase.scaleX = reikaBase.isRight ? 1 : -1;
            reikaBase.stop();
          }

          if (reikaBase.frame % 30 == 0 && GameScene_1.GameScene.getRandom(0, 10) == 0) this.changeDirection(reikaBase);

          _super.prototype.doAction.call(this, reikaBase);
        };

        DirectionalSwimState.prototype.changeDirection = function (reikaBase) {
          reikaBase.start();
          reikaBase.isRight = !reikaBase.isRight;
          this.animationFinished = false;
          reikaBase.modified();
        };

        return DirectionalSwimState;
      }(SwimState_1.SwimState);

      exports.DirectionalSwimState = DirectionalSwimState;
    }, {
      "../GameScene": 20,
      "./SwimState": 30
    }],
    28: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var ReikaStateBase =
      /** @class */
      function () {
        function ReikaStateBase() {}

        return ReikaStateBase;
      }();

      exports.ReikaStateBase = ReikaStateBase;
    }, {}],
    29: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var ReikaStateBase_1 = require("./ReikaStateBase");

      var FeverManager_1 = require("../GameManager/FeverManager");

      var GameScene_1 = require("../GameScene");

      var RollingState =
      /** @class */
      function (_super) {
        __extends(RollingState, _super);

        function RollingState() {
          var _this = _super.call(this) || this;

          _this.isUp = GameScene_1.GameScene.getRandom(0, 1) ? true : false;
          _this.isCatchable = true;
          return _this;
        }

        RollingState.prototype.doAction = function (reikaBase) {
          if (this.isOutOfWidth(reikaBase)) reikaBase.isRight = !reikaBase.isRight;
          if (this.isOutOfHeight(reikaBase)) this.isUp = !this.isUp;
          var distance = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(reikaBase.reikaInfo.speed);
          reikaBase.x += reikaBase.isRight ? -distance : distance;
          reikaBase.y += this.isUp ? -distance : distance;
          reikaBase.angle += FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(3);
          reikaBase.modified();
        };

        RollingState.prototype.isOutOfWidth = function (reikaBase) {
          return reikaBase.x > g.game.width + reikaBase.width || reikaBase.x < -reikaBase.width;
        };

        RollingState.prototype.isOutOfHeight = function (reikaBase) {
          return reikaBase.y + reikaBase.height > g.game.height || reikaBase.y < 120;
        };

        return RollingState;
      }(ReikaStateBase_1.ReikaStateBase);

      exports.RollingState = RollingState;
    }, {
      "../GameManager/FeverManager": 16,
      "../GameScene": 20,
      "./ReikaStateBase": 28
    }],
    30: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var ReikaStateBase_1 = require("./ReikaStateBase");

      var FeverManager_1 = require("../GameManager/FeverManager");

      var SwimState =
      /** @class */
      function (_super) {
        __extends(SwimState, _super);

        function SwimState() {
          var _this = _super.call(this) || this;

          _this.isCatchable = true;
          return _this;
        }

        SwimState.prototype.doAction = function (reikaBase) {
          var distance = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(reikaBase.reikaInfo.speed);
          reikaBase.x += reikaBase.isRight ? -distance : distance;
          this.breath(reikaBase);

          if (this.isOutOfScene(reikaBase)) {
            reikaBase.destroy();
            return;
          }

          reikaBase.invalidate();
        };

        SwimState.prototype.breath = function (reikaBase) {
          var amplitude = 5;
          var wavelength = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(15);
          reikaBase.y = reikaBase.initialY + Math.abs(amplitude * Math.sin(reikaBase.frame / wavelength));
        };

        SwimState.prototype.isOutOfScene = function (reikaBase) {
          return !reikaBase.isRight && reikaBase.x > g.game.width || reikaBase.isRight && reikaBase.x < -reikaBase.width;
        };

        return SwimState;
      }(ReikaStateBase_1.ReikaStateBase);

      exports.SwimState = SwimState;
    }, {
      "../GameManager/FeverManager": 16,
      "./ReikaStateBase": 28
    }],
    31: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var ReikaStateBase_1 = require("./ReikaStateBase");

      var ReikaBase_1 = require("../ReikaBase");

      var SwimState_1 = require("./SwimState");

      var entityUtil_1 = require("../Util/entityUtil");

      var commonDefine_1 = require("../Common/commonDefine");

      var ThrowUntiState =
      /** @class */
      function (_super) {
        __extends(ThrowUntiState, _super);

        function ThrowUntiState() {
          var _this = _super.call(this) || this;

          _this.isCatchable = false;
          _this.isThrew = false;
          _this.frame = 0;
          return _this;
        }

        ThrowUntiState.prototype.doAction = function (reikaBase) {
          this.frame++;
          this.throwUnti(reikaBase);

          if (this.frame == 90) {
            reikaBase.isRight = !reikaBase.isRight;
            reikaBase.scaleX = reikaBase.isRight ? -1 : 1;
            reikaBase.x += reikaBase.isRight ? -50 : +50;
            entityUtil_1.entityUtil.changeSpriteSurface(reikaBase, reikaBase.scene.assets["untireika"]);
            reikaBase.reikaState = new SwimState_1.SwimState();
          }
        };

        ThrowUntiState.prototype.throwUnti = function (reikaBase) {
          if (this.isThrew) return;
          entityUtil_1.entityUtil.changeSpriteSurface(reikaBase, reikaBase.scene.assets["throwunti"]);
          this.createUnti(reikaBase);
          this.isThrew = true;
        };

        ThrowUntiState.prototype.createUnti = function (reikaBase) {
          var unti = new ReikaBase_1.Unti(reikaBase.scene, commonDefine_1.commonDefine.Unti);
          unti.scaleX = reikaBase.isRight ? -1 : 1;
          unti.x = reikaBase.isRight ? reikaBase.x : reikaBase.x + reikaBase.width - unti.width;
          unti.initialY = reikaBase.y;
          unti.y = unti.initialY;
          unti.isRight = reikaBase.isRight;
          entityUtil_1.entityUtil.appendEntity(unti, reikaBase.scene);
        };

        return ThrowUntiState;
      }(ReikaStateBase_1.ReikaStateBase);

      exports.ThrowUntiState = ThrowUntiState;

      var SwimUntiState =
      /** @class */
      function (_super) {
        __extends(SwimUntiState, _super);

        function SwimUntiState() {
          var _this = _super.call(this) || this;

          _this.isCatchable = false;
          return _this;
        }

        SwimUntiState.prototype.doAction = function (reikaBase) {
          _super.prototype.doAction.call(this, reikaBase);

          if (this.getThrowPosition(reikaBase)) reikaBase.reikaState = new ThrowUntiState();
        };

        SwimUntiState.prototype.getThrowPosition = function (reikaBase) {
          return !reikaBase.isRight && reikaBase.x >= -10 || reikaBase.isRight && reikaBase.x <= g.game.width - reikaBase.width + 10;
        };

        return SwimUntiState;
      }(SwimState_1.SwimState);

      exports.SwimUntiState = SwimUntiState;
    }, {
      "../Common/commonDefine": 11,
      "../ReikaBase": 24,
      "../Util/entityUtil": 40,
      "./ReikaStateBase": 28,
      "./SwimState": 30
    }],
    32: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var FeverManager_1 = require("../GameManager/FeverManager");

      var CatchState_1 = require("./CatchState");

      var VibrateCatchState =
      /** @class */
      function (_super) {
        __extends(VibrateCatchState, _super);

        function VibrateCatchState() {
          return _super !== null && _super.apply(this, arguments) || this;
        }

        VibrateCatchState.prototype.doAction = function (reikaBase) {
          var amplitude = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(5);
          var frequency = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(1);
          reikaBase.x += amplitude * Math.sin(reikaBase.frame * frequency);

          _super.prototype.doAction.call(this, reikaBase);
        };

        return VibrateCatchState;
      }(CatchState_1.CatchState);

      exports.VibrateCatchState = VibrateCatchState;
    }, {
      "../GameManager/FeverManager": 16,
      "./CatchState": 25
    }],
    33: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SwimState_1 = require("./SwimState");

      var FeverManager_1 = require("../GameManager/FeverManager");

      var VibrateSwimState =
      /** @class */
      function (_super) {
        __extends(VibrateSwimState, _super);

        function VibrateSwimState() {
          return _super !== null && _super.apply(this, arguments) || this;
        }

        VibrateSwimState.prototype.doAction = function (reikaBase) {
          var amplitude = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(5);
          var frequency = FeverManager_1.FeverManager.getInstance().FeverMagnitudedParameter(1);
          reikaBase.x += amplitude * Math.sin(reikaBase.frame * frequency);

          _super.prototype.doAction.call(this, reikaBase);
        };

        return VibrateSwimState;
      }(SwimState_1.SwimState);

      exports.VibrateSwimState = VibrateSwimState;
    }, {
      "../GameManager/FeverManager": 16,
      "./SwimState": 30
    }],
    34: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SceneBase_1 = require("./SceneBase");

      var entityUtil_1 = require("./Util/entityUtil");

      var ResultScene =
      /** @class */
      function (_super) {
        __extends(ResultScene, _super);

        function ResultScene(property) {
          var _this = _super.call(this, property) || this;

          _this.frame = 0;
          return _this;
        }

        ResultScene.prototype.updateHandler = function () {
          var _this = this;

          return function () {
            _this.frame++;

            if (_this.frame == 2 * g.game.fps) {
              _this.timeoutHandler()();
            } else {
              var value = g.game.vars.gameState.score;
              var len = String(value).length;

              if (_this.isRolling) {
                value = _this.game.random[0].get(Math.pow(10, len - 1), Math.pow(10, len) - 1);
              }

              entityUtil_1.entityUtil.setLabelText(_this.resultLabel, String(value));
            }
          };
        };

        ResultScene.prototype.loadedHandler = function () {
          var _this = this;

          return function () {
            _this.resultBoard = new g.Sprite({
              scene: _this,
              src: _this.assets["result_board"],
              x: 95,
              y: 100,
              scaleX: 1.4,
              scaleY: 1.4
            });
            entityUtil_1.entityUtil.appendEntity(_this.resultBoard, _this);
            _this.resultLabel = entityUtil_1.entityUtil.createResultLabel(6, {
              x: 415,
              y: 200
            }, _this);
            _this.isRolling = true;

            _this.assets["se_No8_RollCount2"].play();
          };
        };

        ResultScene.prototype.timeoutHandler = function () {
          var _this = this;

          return function () {
            _this.isRolling = false;

            _this.assets["se_No8_RollCount2"].stop();

            _this.assets["se_No8_RollCount_Finish"].play();
          };
        };

        return ResultScene;
      }(SceneBase_1.SceneBase);

      exports.ResultScene = ResultScene;
    }, {
      "./SceneBase": 35,
      "./Util/entityUtil": 40
    }],
    35: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SceneBase =
      /** @class */
      function (_super) {
        __extends(SceneBase, _super);

        function SceneBase(property) {
          return _super.call(this, property) || this;
        }

        SceneBase.prototype.init = function (nextScene) {
          var _this = this;

          this.loaded.handle(function () {
            _this.setNextScene(nextScene);

            _this.loadedHandler()();

            _this.update.handle(_this.updateHandler());
          });
        };

        ;

        SceneBase.prototype.setNextScene = function (nextScene) {
          var _this = this;

          this.requestedNextScene = new g.Trigger();
          this.requestedNextScene.handle(function () {
            _this.destroy();

            if (!nextScene) return;
            g.game.pushScene(nextScene);
          });
        };

        return SceneBase;
      }(g.Scene);

      exports.SceneBase = SceneBase;
    }, {}],
    36: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var TimeManager_1 = require("../GameManager/TimeManager");

      var TimeStateBase_1 = require("./TimeStateBase");

      var commonDefine_1 = require("../Common/commonDefine");

      var tl = require("@akashic-extension/akashic-timeline");

      var BeforeEndState =
      /** @class */
      function (_super) {
        __extends(BeforeEndState, _super);

        function BeforeEndState(scene) {
          var _this = _super.call(this, scene) || this;

          _this.isFinished = false;
          _this.timeline = new tl.Timeline(scene);
          _this.timeline2 = new tl.Timeline(scene);
          _this.finishLabel = new g.Sprite({
            scene: scene,
            src: scene.assets["finishLabel"],
            x: 680,
            y: 100
          });
          _this.alertBG = _this.scene.alertBG;
          TimeManager_1.TimeManager.getInstance().timerLabel.changeState();

          _this.alertAnimation();

          return _this;
        }

        BeforeEndState.prototype.doAction = function (timeManager) {
          timeManager.gameUpdate();

          if (timeManager.frameCount % g.game.fps == 0) {
            timeManager.timerLabel.alertAnimation();
            this.alertAnimation();
          }

          if (timeManager.getPlaySec() >= commonDefine_1.commonDefine.GAME_OVER_TIME / 1000) this.finishGame(timeManager.scene);
        };

        BeforeEndState.prototype.finishGame = function (scene) {
          if (this.isFinished) return;
          this.isFinished = true;
          scene.pointDownCapture.removeAll();
          scene.append(this.finishLabel);
          this.gameFinishAnimation(scene);
        };

        BeforeEndState.prototype.alertAnimation = function () {
          this.timeline.clear();
          var tween = this.timeline.create(this.alertBG, {
            modified: this.alertBG.modified,
            destroyed: this.alertBG.destroyed
          });
          tween.fadeIn(500);
          tween.fadeOut(500);
        };

        BeforeEndState.prototype.gameFinishAnimation = function (scene) {
          this.timeline2.clear();
          var tween = this.timeline2.create(this.finishLabel, {
            modified: this.finishLabel.modified,
            destroyed: this.finishLabel.destroyed
          });
          tween.moveTo(20, 100, 200);
          tween.moveBy(0, 0, 1800);
          tween.call(function () {
            scene.requestedNextScene.fire();
          });
        };

        return BeforeEndState;
      }(TimeStateBase_1.TimeStateBase);

      exports.BeforeEndState = BeforeEndState;
    }, {
      "../Common/commonDefine": 11,
      "../GameManager/TimeManager": 19,
      "./TimeStateBase": 39,
      "@akashic-extension/akashic-timeline": 5
    }],
    37: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var TimeStateBase_1 = require("./TimeStateBase");

      var DistributionManager_1 = require("../GameManager/DistributionManager");

      var ReikaManager_1 = require("../GameManager/ReikaManager");

      var BeforeEndState_1 = require("./BeforeEndState");

      var GameScene_1 = require("../GameScene");

      var commonDefine_1 = require("../Common/commonDefine");

      var FeverManager_1 = require("../GameManager/FeverManager");

      var GameProgressState =
      /** @class */
      function (_super) {
        __extends(GameProgressState, _super);

        function GameProgressState(scene) {
          var _this = _super.call(this, scene) || this;

          for (var i = 0; i < 2; i++) {
            var random = GameScene_1.GameScene.getRandom(0, 99);
            var reikaInfo = DistributionManager_1.DistributionManager.getInstance().getReikaInfo(random);
            var reika = ReikaManager_1.ReikaManager.getInstance().getReikaFromName(scene, reikaInfo);
            var randomX = GameScene_1.GameScene.getRandom(0, commonDefine_1.commonDefine.SPAWN_RIGHT_ARRAY.length - 1);
            reika.InitializePosition(i == 0, randomX);
            scene.append(reika);
          }

          FeverManager_1.FeverManager.getInstance().playBGM();
          return _this;
        }

        GameProgressState.prototype.doAction = function (timeManager) {
          timeManager.gameUpdate();
          if (timeManager.remainTime() == commonDefine_1.commonDefine.ALERT_TIME) timeManager.setState(new BeforeEndState_1.BeforeEndState(this.scene));
        };

        return GameProgressState;
      }(TimeStateBase_1.TimeStateBase);

      exports.GameProgressState = GameProgressState;
    }, {
      "../Common/commonDefine": 11,
      "../GameManager/DistributionManager": 15,
      "../GameManager/FeverManager": 16,
      "../GameManager/ReikaManager": 17,
      "../GameScene": 20,
      "./BeforeEndState": 36,
      "./TimeStateBase": 39
    }],
    38: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var GameProgressState_1 = require("./GameProgressState");

      var TimeStateBase_1 = require("./TimeStateBase");

      var commonDefine_1 = require("../Common/commonDefine");

      var tl = require("@akashic-extension/akashic-timeline");

      var entityUtil_1 = require("../Util/entityUtil");

      var ReadyState =
      /** @class */
      function (_super) {
        __extends(ReadyState, _super);

        function ReadyState(scene) {
          var _this = _super.call(this, scene) || this;

          _this.label = entityUtil_1.entityUtil.createRedLabel(1, {
            x: 320,
            y: 160
          }, scene, 40);
          entityUtil_1.entityUtil.setLabelText(_this.label, "3");
          _this.timeline = new tl.Timeline(scene);
          _this.countdown = scene.assets["Countdown"]; //this.gamestart = scene.assets["gamestart"] as g.AudioAsset;

          _this.readyAnimation();

          return _this;
        }

        ReadyState.prototype.doAction = function (timeManager) {
          if (timeManager.getPlaySec() == commonDefine_1.commonDefine.READY_TIME) {
            //this.gamestart.play().changeVolume(0.2);
            timeManager.setState(new GameProgressState_1.GameProgressState(this.scene));
            timeManager.frameCount = 0;
            this.label.destroy();
          }
        };

        ReadyState.prototype.readyAnimation = function () {
          var _this = this;

          this.timeline.clear();
          var tween = this.timeline.create(this.label, {
            modified: this.label.invalidate,
            destroyed: this.label.destroyed
          });

          var _loop_1 = function _loop_1(i) {
            tween.call(function () {
              _this.countdown.play().changeVolume(0.2);
            });
            tween.to({
              scaleX: 1.4,
              scaleY: 1.4
            }, commonDefine_1.commonDefine.READY_TIME * 1000 / 3);
            tween.call(function () {
              _this.label.scaleX = 1.0;
              _this.label.scaleY = 1.0;
              entityUtil_1.entityUtil.setLabelText(_this.label, (commonDefine_1.commonDefine.READY_TIME - i - 1).toString());
            });
          };

          for (var i = 0; i < commonDefine_1.commonDefine.READY_TIME; i++) {
            _loop_1(i);
          }
        };

        return ReadyState;
      }(TimeStateBase_1.TimeStateBase);

      exports.ReadyState = ReadyState;
    }, {
      "../Common/commonDefine": 11,
      "../Util/entityUtil": 40,
      "./GameProgressState": 37,
      "./TimeStateBase": 39,
      "@akashic-extension/akashic-timeline": 5
    }],
    39: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var TimeStateBase =
      /** @class */
      function () {
        function TimeStateBase(scene) {
          this.scene = scene;
        }

        return TimeStateBase;
      }();

      exports.TimeStateBase = TimeStateBase;
    }, {}],
    40: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var assetInfo_1 = require("../assetInfo");

      var gameUtil_1 = require("./gameUtil");
      /**
       * g.Eとそのサブクラス（g.Spriteを除く）を扱うユーティリティ関数群
       */


      var entityUtil;

      (function (entityUtil) {
        /**
         * Entityのappendとmodifiedを行う
         * @param _entity addend対象のエンティティ
         * @param _parent addend先のエンティティ
         */
        function appendEntity(_entity, _parent) {
          _parent.append(_entity);

          _entity.modified();
        }

        entityUtil.appendEntity = appendEntity;
        /**
         * Entityのhideとmodifiedを行う
         * @param _entity 処理対象のEntity
         */

        function hideEntity(_entity) {
          _entity.hide();

          _entity.modified();
        }

        entityUtil.hideEntity = hideEntity;
        /**
         * Entityのshowとmodifiedを行う
         * @param _entity 処理対象のEntity
         */

        function showEntity(_entity) {
          _entity.show();

          _entity.modified();
        }

        entityUtil.showEntity = showEntity;
        /**
         * Entityのx/yの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _x      設定するx座標
         * @param _y      設定するy座標
         */

        function setXY(_entity, _x, _y) {
          _entity.x = _x;
          _entity.y = _y;

          _entity.modified();
        }

        entityUtil.setXY = setXY;
        /**
         * Entityのxの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _x      設定するx座標
         */

        function setX(_entity, _x) {
          _entity.x = _x;

          _entity.modified();
        }

        entityUtil.setX = setX;
        /**
         * Entityのyの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _y      設定するy座標
         */

        function setY(_entity, _y) {
          _entity.y = _y;

          _entity.modified();
        }

        entityUtil.setY = setY;
        /**
         * Entityのopacityの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _opacity 設定する値
         */

        function setOpacity(_entity, _opacity) {
          _entity.opacity = _opacity;

          _entity.modified();
        }

        entityUtil.setOpacity = setOpacity;
        /**
         * EntityのscaleX/scaleYの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _scale  設定する値
         */

        function setScale(_entity, _scale) {
          _entity.scaleX = _scale;
          _entity.scaleY = _scale;

          _entity.modified();
        }

        entityUtil.setScale = setScale;
        /**
         * Labelの生成とaligning、fontSizeの設定を行う
         * @param  _scene      Labelの生成に使用するScene
         * @param  _text       Labelに初期設定する文字列
         * @param  _bitmapFont 使用するBitmapFont
         * @param  _maxLength  想定する桁数
         * @param  _align      設定するTextAlign
         * @return             生成したLabel
         */

        function createLabel(_scene, _text, _bitmapFont, _maxLength, _align, fontSize) {
          var label = new g.Label({
            scene: _scene,
            text: _text,
            font: _bitmapFont,
            fontSize: _bitmapFont.defaultGlyphHeight
          });
          if (fontSize) label.fontSize = fontSize;
          label.aligning(_bitmapFont.defaultGlyphWidth * _maxLength, _align);
          label.invalidate();
          return label;
        }

        entityUtil.createLabel = createLabel;
        /**
         * 数字用のcreateLabelのショートハンド
         * _textは桁数分の9埋め文字列、_alignはRightに設定する。
         * @param  _scene      Labelの生成に使用するScene
         * @param  _bitmapFont 使用するBitmapFont
         * @param  _digit      想定する桁数
         * @return             生成したLabel
         */

        function createNumLabel(_scene, _bitmapFont, _digit, fontSize) {
          var nums = [];

          for (var i = 0; i < _digit; ++i) {
            nums[nums.length] = "9";
          }

          var text = nums.join("");
          var label = createLabel(_scene, text, _bitmapFont, _digit, g.TextAlign.Right, fontSize);
          return label;
        }

        entityUtil.createNumLabel = createNumLabel;
        /**
         * 右端の数字の左上を指定してラベルの位置を設定するメソッド
         * @param  _label 処理対象のLabel
         * @param  _x     右端の数字の左上のx座標
         * @param  _y     右端の数字の左上のy座標
         */

        function moveNumLabelTo(_label, _x, _y) {
          _label.x = _x + _label.font.defaultGlyphWidth - _label.width;
          _label.y = _y;

          _label.modified();
        }

        entityUtil.moveNumLabelTo = moveNumLabelTo;
        /**
         * Label.textの設定とinvalidateを行う
         * @param _label 処理対象のLabel
         * @param _text  設定する文字列
         */

        function setLabelText(_label, _text) {
          _label.text = _text;

          _label.invalidate();
        }

        entityUtil.setLabelText = setLabelText;
        /**
         * Entityの子要素を全てdestroyする
         * @param _e 処理対象のE
         */

        function destroyAllChildren(_e) {
          if (!_e.children) return; // Childrenが未定義であれば何もしない

          var end = _e.children.length - 1;

          for (var i = end; i >= 0; --i) {
            if (!_e.children[i].destroyed()) {
              _e.children[i].destroy();
            }
          }
        }

        entityUtil.destroyAllChildren = destroyAllChildren;

        function createWhiteLabel(_digit, _posStart, _scene, fontSize) {
          var fontStgNum1 = gameUtil_1.gameUtil.createNumFontWithAssetInfo(assetInfo_1.AssetInfo.numWhite);

          var _label = createNumLabel(_scene, fontStgNum1, _digit, fontSize);

          appendEntity(_label, _scene);
          moveNumLabelTo( // 1ケタ目左上へ移動
          _label, _posStart.x, _posStart.y); // ラベル初期位置記憶
          //this.posLabelStart = { x: this.scoreLabel.x, y: this.scoreLabel.y };

          return _label;
        }

        entityUtil.createWhiteLabel = createWhiteLabel;

        function createRedLabel(_digit, _posStart, _scene, fontSize) {
          var fontStgNum1 = gameUtil_1.gameUtil.createNumFontWithAssetInfo(assetInfo_1.AssetInfo.numRed);

          var _label = createNumLabel(_scene, fontStgNum1, _digit, fontSize);

          appendEntity(_label, _scene);
          moveNumLabelTo( // 1ケタ目左上へ移動
          _label, _posStart.x, _posStart.y); // ラベル初期位置記憶
          //this.posLabelStart = { x: this.scoreLabel.x, y: this.scoreLabel.y };

          return _label;
        }

        entityUtil.createRedLabel = createRedLabel;

        function createResultLabel(_digit, _posStart, _scene, fontSize) {
          var fontStgNum1 = gameUtil_1.gameUtil.createNumFontWithAssetInfo(assetInfo_1.AssetInfo.numResult);

          var _label = createNumLabel(_scene, fontStgNum1, _digit, fontSize);

          appendEntity(_label, _scene);
          moveNumLabelTo( // 1ケタ目左上へ移動
          _label, _posStart.x, _posStart.y); // ラベル初期位置記憶
          //this.posLabelStart = { x: this.scoreLabel.x, y: this.scoreLabel.y };

          return _label;
        }

        entityUtil.createResultLabel = createResultLabel;

        function changeSpriteSurface(_sprite, _asset) {
          _sprite.surface = _asset.asSurface();

          _sprite.invalidate();
        }

        entityUtil.changeSpriteSurface = changeSpriteSurface;
      })(entityUtil = exports.entityUtil || (exports.entityUtil = {}));
    }, {
      "../assetInfo": 42,
      "./gameUtil": 41
    }],
    41: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /** 0のキャラクターコード */

      exports.CHAR_CODE_0 = 48;
      /** 9のキャラクターコード+1 */

      exports.CHAR_CODE_10 = 58;
      var gameUtil;

      (function (gameUtil) {
        function makeGlyphMapFromFrames(_charCodeStart, _charCodeEnd, _json, _frames) {
          var map = {};

          for (var i = 0; i < _charCodeEnd - _charCodeStart; ++i) {
            var frame = _json.frames[_frames[i]].frame;
            map[i + _charCodeStart] = {
              x: frame.x,
              y: frame.y,
              width: frame.w,
              height: frame.h
            };
          } //+を追加

          /*map[43] = {x:_json.frames["num_R_export0012.png"].frame.x,
                     y:_json.frames["num_R_export0012.png"].frame.y,
                     width:_json.frames["num_R_export0012.png"].frame.w,
                     height:_json.frames["num_R_export0012.png"].frame.height
                  };
          */


          return map;
        }

        gameUtil.makeGlyphMapFromFrames = makeGlyphMapFromFrames;

        function addOneGlyphMapFromFrame(_oneChar, _json, _frameName, _map) {
          var frame = _json.frames[_frameName].frame;
          console.log(_oneChar.charCodeAt(0));
          _map[_oneChar.charCodeAt(0)] = {
            x: frame.x,
            y: frame.y,
            width: frame.w,
            height: frame.h
          };
        }

        gameUtil.addOneGlyphMapFromFrame = addOneGlyphMapFromFrame;

        function createNumFontWithAssetInfo(_info, opt_assets) {
          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          }

          var frameMap = JSON.parse(opt_assets[_info.json].data);
          var glyphMap = gameUtil.makeGlyphMapFromFrames(exports.CHAR_CODE_0, exports.CHAR_CODE_10, frameMap, _info.numFrames);

          if (_info.nonnumFrames) {
            var iEnd = _info.nonnumFrames.length;

            for (var i = 0; i < iEnd; ++i) {
              var oneChar = _info.nonnumFrames[i];
              addOneGlyphMapFromFrame(oneChar.char, frameMap, oneChar.frame, glyphMap);
            }
          }

          var missingGlyph;

          if (_info.missing) {
            var frame = frameMap.frames[_info.missing].frame;
            missingGlyph = {
              x: frame.x,
              y: frame.y,
              width: frame.w,
              height: frame.h
            };
          }

          var font = new g.BitmapFont({
            src: opt_assets[_info.img],
            map: glyphMap,
            defaultGlyphWidth: _info.fontWidth,
            defaultGlyphHeight: _info.fontHeight,
            missingGlyph: missingGlyph
          });
          return font;
        }

        gameUtil.createNumFontWithAssetInfo = createNumFontWithAssetInfo;

        function updateGameStateScore(_score) {
          /*const gameState = <GameStateType>g.game.vars.gameState;
          if (gameState && (!gameState.isFinished)) {
              gameState.score = _score;
          }*/
          g.game.vars.gameState.score = _score; // console.log("updateGameStateScore: gameState.score:" + g.game.vars.gameState.score + ".");
        }

        gameUtil.updateGameStateScore = updateGameStateScore;
      })(gameUtil = exports.gameUtil || (exports.gameUtil = {}));
    }, {}],
    42: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 画像アセット関連の静的情報
       */

      var AssetInfo =
      /** @class */
      function () {
        function AssetInfo() {}

        AssetInfo.getWaveProperty = function (scene) {
          return {
            scene: scene,
            height: 100,
            width: 700,
            x: -20,
            y: 90,
            src: scene.assets["wave"],
            srcWidth: 700,
            srcHeight: 100,
            frames: [0, 1, 2, 3],
            interval: 1000,
            loop: true
          };
        };

        AssetInfo.getSunProperty = function (scene) {
          return {
            scene: scene,
            height: 60,
            width: 60,
            x: 0,
            y: 0,
            src: scene.assets["sun"],
            srcWidth: 100,
            srcHeight: 100,
            frames: [0, 1],
            interval: 1300,
            loop: true
          };
        };

        AssetInfo.getAnglerProperty = function (scene) {
          return {
            scene: scene,
            src: scene.assets["tsuribito"],
            x: 100,
            y: 5,
            srcWidth: 550,
            srcHeight: 523,
            width: 140,
            height: 140
          };
        };

        AssetInfo.getLineProperty = function (scene) {
          return {
            scene: scene,
            src: scene.assets["tsurizao"],
            x: 100 + 130,
            y: 10 + 10,
            srcWidth: 14,
            srcHeight: 480,
            width: 14,
            height: 300
          };
        };

        AssetInfo.getThunderProperty = function (scene) {
          return {
            scene: scene,
            height: 200,
            width: 200,
            x: 30,
            y: -20,
            src: scene.assets["thunder"],
            srcWidth: 550,
            srcHeight: 523,
            frames: [0, 1],
            interval: 200,
            loop: true
          };
        };

        AssetInfo.gameAssets = ["normal", "normal_caught", "huwareika", "yureika", "tsuribito", "tsurizao", "tsuribito2", "tsuribito3", "img_stg_num1", "json_stg_num1", "img_stg_num2", "json_stg_num2", "img_stg_num3", "json_stg_num3", "pt", "time", "wave", "finishLabel", "gyakureika", "bikkurireika", "odoreika", "reikatyon", "nemureika", "gatareika", "takoreika", "yuizarashi", "maxgage", "gage", "se_real57", "reppu", "konoyaro", "needle", "needle2", "thunder", "bgm", "catchSE", "unti", "untireika", "throwunti", "unticaught", "getreika", "paralysisSound", "yuizarashi2", "alertBG", "Countdown", "gamestart", "sun", "catchFeverSE"];
        AssetInfo.resultAssets = ["result_board", "json_num_result", "img_num_result", "se_No8_RollCount2", "se_No8_RollCount_Finish"];
        AssetInfo.descriptionAssets = ["title"];
        /** ゲーム中の数字（白） */
        // tslint:disable-next-line:typedef

        AssetInfo.numWhite = {
          img: "img_stg_num1",
          json: "json_stg_num1",
          numFrames: ["num_W_export0001.png", "num_W_export0002.png", "num_W_export0003.png", "num_W_export0004.png", "num_W_export0005.png", "num_W_export0006.png", "num_W_export0007.png", "num_W_export0008.png", "num_W_export0009.png", "num_W_export0010.png"],
          frames: {
            cross: "num_W_export0011.png",
            plus: "num_W_export0012.png",
            minus: "num_W_export0013.png"
          },
          fontWidth: 26,
          fontHeight: 30
        };
        AssetInfo.numResult = {
          img: "img_num_result",
          json: "json_num_result",
          frames: {
            cross: "num_result_0011.png",
            plus: "num_result_0012.png",
            minus: "num_result_0013.png"
          },
          numFrames: ["num_result_0001.png", "num_result_0002.png", "num_result_0003.png", "num_result_0004.png", "num_result_0005.png", "num_result_0006.png", "num_result_0007.png", "num_result_0008.png", "num_result_0009.png", "num_result_0010.png"],
          fontWidth: 70,
          fontHeight: 81
        };
        AssetInfo.numRed = {
          img: "img_stg_num2",
          json: "json_stg_num2",
          numFrames: ["num_R_export0001.png", "num_R_export0002.png", "num_R_export0003.png", "num_R_export0004.png", "num_R_export0005.png", "num_R_export0006.png", "num_R_export0007.png", "num_R_export0008.png", "num_R_export0009.png", "num_R_export0010.png"],
          nonnumFrames: [{
            char: "*",
            frame: "num_R_export0011.png"
          }, {
            char: "+",
            frame: "num_R_export0012.png"
          }, {
            char: "-",
            frame: "num_R_export0013.png"
          }],
          fontWidth: 26,
          fontHeight: 30
        };
        AssetInfo.numBlue = {
          img: "img_stg_num3",
          json: "json_stg_num3",
          numFrames: ["num_Bl_export0001.png", "num_Bl_export0002.png", "num_Bl_export0003.png", "num_Bl_export0004.png", "num_Bl_export0005.png", "num_Bl_export0006.png", "num_Bl_export0007.png", "num_Bl_export0008.png", "num_Bl_export0009.png", "num_Bl_export0010.png"],
          frames: {
            cross: "num_Bl_export0011.png",
            plus: "num_Bl_export0012.png",
            minus: "num_Bl_export0013.png"
          },
          fontWidth: 26,
          fontHeight: 30
        };
        /** ゲーム中の数字（黄色 コンボ） */
        // tslint:disable-next-line:typedef

        AssetInfo.numCb = {
          img: "img_num_cb",
          json: "json_num_cb",
          numFrames: ["num_Cb_export0001.png", "num_Cb_export0002.png", "num_Cb_export0003.png", "num_Cb_export0004.png", "num_Cb_export0005.png", "num_Cb_export0006.png", "num_Cb_export0007.png", "num_Cb_export0008.png", "num_Cb_export0009.png", "num_Cb_export0010.png"],
          frames: {
            cross: "num_Cb_export0011.png",
            plus: "num_Cb_export0012.png",
            minus: "num_Cb_export0013.png"
          },
          fontWidth: 30,
          fontHeight: 34
        };
        return AssetInfo;
      }();

      exports.AssetInfo = AssetInfo;
    }, {}],
    43: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * ゲーム関連の静的情報
       */

      var define;

      (function (define) {
        /** 基本スコア */
        define.SCORE_BASE = 100;
        /** マイナススコア */

        define.SCORE_MINUS = -50;
        /** スコア上限 */

        define.SCORE_LIMIT = Math.pow(10, 6) - 1;
      })(define = exports.define || (exports.define = {}));
    }, {}],
    44: [function (require, module, exports) {
      "use strict";

      var assetInfo_1 = require("./assetInfo");

      var GameScene_1 = require("./GameScene");

      var ResultScene_1 = require("./ResultScene");

      var DescriptionScene_1 = require("./DescriptionScene");

      function main(param) {
        var descriptionScene = new DescriptionScene_1.DescriptionScene({
          game: g.game,
          assetIds: assetInfo_1.AssetInfo.descriptionAssets
        });
        var gameScene = new GameScene_1.GameScene({
          game: g.game,
          assetIds: assetInfo_1.AssetInfo.gameAssets
        });
        var resultScene = new ResultScene_1.ResultScene({
          game: g.game,
          assetIds: assetInfo_1.AssetInfo.resultAssets
        }); // 何も送られてこない時は、標準の乱数生成器を使う

        var random = new g.XorshiftRandomGenerator(new Date().getSeconds());
        descriptionScene.message.handle(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            console.log("msg.data");
            var sessionParameters = msg.data.parameters;

            if (sessionParameters.randomSeed != null) {
              // プレイヤー間で共通の乱数生成器を生成
              // `g.XorshiftRandomGenerator` は Akashic Engine の提供する乱数生成器実装で、 `g.game.random` と同じ型。
              random = new g.XorshiftRandomGenerator(sessionParameters.randomSeed);
              console.log(random.get(0, 100));
            }
          }
        });
        descriptionScene.init(gameScene);
        gameScene.init(resultScene);
        resultScene.init();
        g.game.pushScene(descriptionScene);
      }

      module.exports = main;
    }, {
      "./DescriptionScene": 13,
      "./GameScene": 20,
      "./ResultScene": 34,
      "./assetInfo": 42
    }]
  }, {}, [44])(44);
});